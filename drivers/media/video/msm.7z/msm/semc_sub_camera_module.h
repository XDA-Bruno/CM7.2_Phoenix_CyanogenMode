/* drivers/media/video/msm/semc_sub_camera_module.h
 *
 * Copyright (C) 2010 Sony Ericsson Mobile Communications AB.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2, as
 * published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 */

#ifndef CAMSENSOR_SEMC_SUB_CAMERA_MODULE
#define CAMSENSOR_SEMC_SUB_CAMERA_MODULE

#include <linux/types.h>

#endif /* CAMSENSOR_SEMC_SUB_CAMERA_MODULE */
